import React from 'react';

const Testimonial = ({ img, imgAlt, name, desc }) => {
  return (
    <article>
      <img src={img} alt={imgAlt} />
      <div className='card-text'>
        <h4>{name}</h4>
        <p>{desc}</p>
      </div>
    </article>
  );
}

export default Testimonial;
