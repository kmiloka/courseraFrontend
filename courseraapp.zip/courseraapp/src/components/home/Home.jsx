import React from 'react'
import Hero from './Hero'
import Specialities from './Specialities'
import Testimonials from './Testimonials'
import About from './About'

const Home = () => {
  return (
    <main>
        <Hero />
        <Specialities />
        <Testimonials />
        <About />
    </main>
  )
}

export default Home