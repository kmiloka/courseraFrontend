import React from 'react';
import Nav from './Nav';
import logo from '../assets/Logo.svg';

const Header = () => {
  return (
    <header>
      <a href='/' aria-label="Homepage">
        <img src={logo} alt="Company Logo" />
      </a>
      <Nav />
    </header>
  );
}

export default Header;
