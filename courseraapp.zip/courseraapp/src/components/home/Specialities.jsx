import React from 'react';
import saladImg from '../../assets/greek salad.jpg';
import cakeImg from '../../assets/lemon dessert.jpg';
import bruchettaImg from '../../assets/bruchetta.svg';
import Speciality from './Speciality';

const Specialities = () => {
  return (
    <section className='speciality'>
      <h2>Our Specialities</h2>
      <div className='cards'>
        <Speciality 
          img={saladImg} 
          imgAlt='A bowl of Greek salad' 
          title='Greek Salad' 
          price={23.99}
          desc='Lorem ipsum dolor sit amet, consectetur adipiscing elit. Phasellus vulputate purus eget libero tristique, 
          vel congue risus ullamcorper. Integer nec est nisi.' 
        />
        <Speciality 
          img={cakeImg} 
          imgAlt='A slice of lemon cake' 
          title='Lemon Cake' 
          price={11.99}
          desc='Lorem ipsum dolor sit amet, consectetur adipiscing elit. Phasellus vulputate purus eget libero tristique, 
          vel congue risus ullamcorper. Integer nec est nisi.' 
        />
        <Speciality 
          img={bruchettaImg} 
          imgAlt='A plate of Bruchetta' 
          title='Bruchetta' 
          price={15.99}
          desc='Lorem ipsum dolor sit amet, consectetur adipiscing elit. Phasellus vulputate purus eget libero tristique, 
          vel congue risus ullamcorper. Integer nec est nisi.' 
        />
      </div>
    </section>
  );
}

export default Specialities;
