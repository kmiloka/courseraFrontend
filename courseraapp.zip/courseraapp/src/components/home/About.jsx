import React from 'react';
import restaurantImage from '../../assets/restaurant.jpg';
import ownersImage from '../../assets/Mario and Adrian A.jpg';
import chefImage from '../../assets/restaurant chef B.jpg';
import foodImage from '../../assets/restauranfood.jpg';

const About = () => {
  return (
    <section className='about'>
      <div className='about__text'>
        <h2>About <span className='title'>Little Lemon</span> <span className='spot'>Tokyo</span></h2>
        <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Phasellus vulputate purus eget libero tristique,
          vel congue risus ullamcorper. Integer nec est nisi. Curabitur sed nunc pellentesque, tempor eros eu, semper urna.
          Nullam tristique luctus risus tincidunt faucibus. Aliquam in aliquam nisl.
        </p>
        <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Phasellus vulputate purus eget libero tristique,
          vel congue risus ullamcorper. Integer nec est nisi.
        </p>
        <p>Integer nec est nisi. Curabitur sed nunc pellentesque, tempor eros eu, semper urna.
          Nullam tristique luctus risus tincidunt faucibus. Aliquam in aliquam nisl.
        </p>
      </div>
      <div className='about__imgs'>
        <img src={restaurantImage} alt='Inside view of the restaurant' />
        <img src={ownersImage} alt='Owners of the restaurant, Mario and Adrian' />
        <img src={chefImage} alt='Head chef in the kitchen' />
        <img src={foodImage} alt='Delicious food served at the restaurant' />
      </div>
    </section>
  );
}

export default About;
