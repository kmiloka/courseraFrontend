import React from 'react';

const Speciality = ({ img, imgAlt, title, desc, price }) => {
  return (
    <article>
      <img src={img} alt={imgAlt} />
      <div className='card-text'>
        <h3>{title}</h3>
        <p>{desc}</p>
        <div className='card-text__bottom'>
          <span>${price}</span>
          <button>Order</button>
        </div>
      </div>
    </article>
  );
}

export default Speciality;
