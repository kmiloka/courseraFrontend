import React from 'react';
import logo from '../assets/Logo.svg';

const Footer = () => {
  return (
    <footer>
      <a href='/' aria-label="Homepage">
        <img src={logo} alt="Company Logo" />
      </a>
      <section aria-labelledby="footer-navigation">
        <h2 id="footer-navigation">Navigation</h2>
        <ul>
          <li><a href='/about'>About</a></li>
          <li><a href='/menu'>Menu</a></li>
          <li><a href='/reserve'>Reserve</a></li>
          <li><a href='/order'>Order</a></li>
        </ul>
      </section>
      <section aria-labelledby="footer-contact">
        <h2 id="footer-contact">Contact</h2>
        <ul>
          <li><a href='/address'>Address</a></li>
          <li><a href='/email'>Email</a></li>
          <li><a href='/phone'>Phone number</a></li>
        </ul>
      </section>
      <section aria-labelledby="footer-socials">
        <h2 id="footer-socials">Socials</h2>
        <ul>
          <li><a href='https://www.facebook.com'>Facebook</a></li>
          <li><a href='https://www.instagram.com'>Instagram</a></li>
          <li><a href='https://www.tiktok.com'>Tiktok</a></li>
        </ul>
      </section>
    </footer>
  );
}

export default Footer;
