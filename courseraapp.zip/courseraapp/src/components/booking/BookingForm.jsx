import React, { useState } from 'react';

const BookingForm = () => {
  const [formData, setFormData] = useState({
    name: '',
    email: '',
    date: '',
    time: '',
    guests: '',
    occasion: 'No occasion',
  });

  const [formSubmitted, setFormSubmitted] = useState(false);
  const [formErrors, setFormErrors] = useState({});

  const handleChange = (e) => {
    const { name, value } = e.target;
    setFormData({
      ...formData,
      [name]: value,
    });
  };

  const validateForm = () => {
    const errors = {};
    if (!formData.name) errors.name = 'Name is required';
    if (!formData.email) errors.email = 'Email is required';
    if (!formData.date) errors.date = 'Date is required';
    if (!formData.time) errors.time = 'Time is required';
    if (!formData.guests) errors.guests = 'Number of guests is required';
    return errors;
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    const errors = validateForm();
    if (Object.keys(errors).length === 0) {
      setFormSubmitted(true);
    } else {
      setFormErrors(errors);
    }
  };

  if (formSubmitted) {
    return (
      <section className='submitted-form'>
        <h1>Success!</h1>
        <h2>Your table has been booked.</h2>
        <div className='booking-details'>
          <p><strong>Name:</strong> {formData.name}</p>
          <p><strong>Email:</strong> {formData.email}</p>
          <p><strong>Date:</strong> {formData.date}</p>
          <p><strong>Time:</strong> {formData.time}</p>
          <p><strong>Number of Guests:</strong> {formData.guests}</p>
          <p><strong>Occasion:</strong> {formData.occasion}</p>
        </div>
      </section>
    );
  }

  return (
    <section className='form'>
      <h1>Book a table</h1>
      <p>Make sure you fill all the fields correctly before submitting the form.</p>
      <form onSubmit={handleSubmit} aria-live="polite">
        <div className='form-field'>
          <label htmlFor='name'>Name:</label>
          <input
            type='text'
            id='name'
            name='name'
            placeholder='Provide your full name'
            value={formData.name}
            onChange={handleChange}
            aria-describedby={formErrors.name ? 'name-error' : null}
          />
          {formErrors.name && <span id='name-error' className='error'>{formErrors.name}</span>}
        </div>
        <div className='form-field'>
          <label htmlFor='email'>Email:</label>
          <input
            type='email'
            id='email'
            name='email'
            placeholder='Provide correct email ex. john@mail.com'
            value={formData.email}
            onChange={handleChange}
            aria-describedby={formErrors.email ? 'email-error' : null}
          />
          {formErrors.email && <span id='email-error' className='error'>{formErrors.email}</span>}
        </div>
        <div className='form-field'>
          <label htmlFor='date'>Choose date:</label>
          <input
            type='date'
            id='date'
            name='date'
            value={formData.date}
            onChange={handleChange}
            aria-describedby={formErrors.date ? 'date-error' : null}
          />
          {formErrors.date && <span id='date-error' className='error'>{formErrors.date}</span>}
        </div>
        <div className='form-field'>
          <label htmlFor='time'>Choose time:</label>
          <input
            type='time'
            id='time'
            name='time'
            value={formData.time}
            onChange={handleChange}
            aria-describedby={formErrors.time ? 'time-error' : null}
          />
          {formErrors.time && <span id='time-error' className='error'>{formErrors.time}</span>}
        </div>
        <div className='form-field'>
          <label htmlFor='guests'>Number of guests:</label>
          <input
            type='number'
            id='guests'
            name='guests'
            placeholder='Choose number from 1 to maximum 20'
            min={1}
            max={20}
            value={formData.guests}
            onChange={handleChange}
            aria-describedby={formErrors.guests ? 'guests-error' : null}
          />
          {formErrors.guests && <span id='guests-error' className='error'>{formErrors.guests}</span>}
        </div>
        <div className='form-field'>
          <label htmlFor='occasion'>Occasion:</label>
          <select
            id='occasion'
            name='occasion'
            value={formData.occasion}
            onChange={handleChange}
          >
            <option>No occasion</option>
            <option>Anniversary</option>
            <option>Engagement</option>
            <option>Birthday</option>
            <option>Date</option>
          </select>
        </div>
        <button type='submit'>Book a table</button>
      </form>
    </section>
  );
};

export default BookingForm;
