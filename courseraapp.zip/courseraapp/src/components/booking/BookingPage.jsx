import React from 'react';
import heroImg from '../../assets/restauranfood.jpg';
import './Booking.scss';
import BookingForm from './BookingForm';

const BookingPage = ({ availableTimes, dispatch }) => {
  return (
    <main className='booking-page'>
      <section className='title-section'>
        <img src={heroImg} alt="A delicious dish served at the restaurant" />
        <div className='overlay' aria-hidden="true" />
        <div className='text-overlay'>
          <h1>Book a table</h1>
        </div>
      </section>
      <BookingForm availableTimes={availableTimes} dispatch={dispatch} />
    </main>
  );
};

export default BookingPage;
