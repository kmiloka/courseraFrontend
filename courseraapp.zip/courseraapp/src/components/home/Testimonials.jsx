import React from 'react';
import avatar from '../../assets/Mario and Adrian b.jpg';
import avatar2 from '../../assets/Mario and Adrian A.jpg';
import Testimonial from './Testimonial';

const Testimonials = () => {
  return (
    <section className='testimonials'>
      <h2>Testimonials</h2>
      <div className='cards'>
        <Testimonial 
          img={avatar} 
          imgAlt="John Smith's avatar" 
          name="John Smith" 
          desc='Lorem ipsum dolor sit amet, consectetur adipiscing elit. Phasellus vulputate purus eget libero tristique, vel congue risus ullamcorper.' 
        />
        <Testimonial 
          img={avatar2} 
          imgAlt="Mateo Linguini's avatar" 
          name="Mateo Linguini" 
          desc='Lorem ipsum dolor sit amet, consectetur adipiscing elit. Phasellus vulputate purus eget libero tristique, vel congue risus ullamcorper.' 
        />
        <Testimonial 
          img={avatar} 
          imgAlt="Adrian Sole's avatar" 
          name="Adrian Sole" 
          desc='Lorem ipsum dolor sit amet, consectetur adipiscing elit. Phasellus vulputate purus eget libero tristique, vel congue risus ullamcorper.' 
        />
      </div>
    </section>
  );
}

export default Testimonials;
