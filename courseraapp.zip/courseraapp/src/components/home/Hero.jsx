import React from 'react';
import img from '../../assets/restauranfood.jpg';

const Hero = () => {
  return (
    <section className='hero'>
      <div className='hero__text'>
        <h1>Little Lemon</h1>
        <span>Tokyo</span>
        <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Phasellus vulputate purus eget libero tristique,
          vel congue risus ullamcorper. Integer nec est nisi. Curabitur sed nunc pellentesque, tempor eros eu, semper urna.
          Nullam tristique luctus risus tincidunt faucibus. Aliquam in aliquam nisl.
        </p>
        <a href='/' aria-label="Reserve a table">Reserve table</a>
      </div>
      <div>
        <img src={img} alt='A plate of Bruchetta served at the restaurant' />
      </div>
    </section>
  );
}

export default Hero;
